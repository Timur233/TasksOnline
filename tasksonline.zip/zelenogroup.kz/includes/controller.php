<?php
require "db.php";

$DB = new dataBase();

if ($_POST['modInput'] == 'insertTask') {
    $name = strip_tags($_POST['name']);
    $email = strip_tags($_POST['email']);
    $task = strip_tags($_POST['task']);
    $status = strip_tags($_POST['status']);
    $edit = strip_tags($_POST['edit']);

    $DB->insertTask($name, $email, $task, $status, $edit);
    echo json_encode("Задача успешно создана!");
    exit;
}

if ($_POST['modInput'] == 'selectTask') {

    $sort = $_POST['sort'];
    $offset = $_POST['offset'];

    $rows = $DB->selectTasks($sort, $offset);
    $result = '';
    while ($row = $rows->fetch_assoc()) {
        $result .= '<tr>';
        $result .= '<th scope="row">' . $row['name'] . '</th>';
        $result .= '<td>' . $row['email'] . '</td>';
        $result .= '<td>' . $row['task'] . '</td>';

        switch ($row['status']) {
            case 0:
                $result .= '<td class="text-right"><a href="#" class="badge badge-pill badge-secondary">Ожидание</a></td>';
                break;
            case 1:
                $result .= '<td class="text-right"><a href="#" class="badge badge-pill badge-warning">Выполнение</a></td>';
                break;
            case 2:
                $result .= '<td class="text-right"><a href="#" class="badge badge-pill badge-success">Выполненно</a></td>';
                break;
        }

        $result .= '</tr>';
    }

    echo $result;
    exit;

}

if ($_POST['modInput'] == 'paginationTask') {

    $rows = $DB->paginationTasks();
    $pages = ceil($rows/3);
    $result = '';
    $offset = 0;

    for ($i=1; $i <= $pages; $i++){
        $offset = ($i*3)-3;
        if ($i==1){
            $result .= '<li class="page-item"><a class="first-page page-link pagination-link active" data-offset="'.$offset.'" href="#">'.$i.'</a></li>';
        } else {
            $result .= '<li class="page-item"><a class="page-link pagination-link" data-offset="'.$offset.'" href="#">'.$i.'</a></li>';
        }
    }

    echo $result;
    exit;
}

if ($_POST['modInput'] == 'loginUser'){
    if ($_POST['login'] == 'admin' && $_POST['pass'] == '123'){
        SetCookie("user","admin");
    } else {
        header('HTTP/1.1 500 Internal Server Booboo');
        header('Content-Type: application/json; charset=UTF-8');
    }
    exit;
}

?>