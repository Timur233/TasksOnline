<?php

//require "includes/db.php";

//ini_set('error_reporting', E_ALL);
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);

//$DB = new dataBase();
//$rows = $DB->selectTasks('id', 'ASC');

//if ($_GET['modInput'] == 'insertTask'){
  //  $DB->insertTask($_GET['name'], $_GET['email'], $_GET['task'], $_GET['status'], $_GET['edit']);
//}

?>
<!DOCTYPE html>
<html class="gt-ie8 gt-ie9 not-ie pxajs">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>Онлайн задачник</title>
    <meta name="viewport"
          content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,600i,700,700i,800,800i&display=swap&subset=cyrillic,cyrillic-ext" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>

</head>
<body>
<header class="bg-light mb-5">
    <nav class="navbar navbar-expand-lg navbar-light container">
        <a class="navbar-brand" href="/">Задачи <span class="badge badge-info">онлайн</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="/">Задачи</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="/newTask.php">Создать задачу<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/login">Войти</a>
                </li>
            </ul>
        </div>
    </nav>
</header>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h4>Создать задачу</h4>
            <form id="ajaxForm" method="post" class="mt-4">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="nameInput">Имя</label>
                        <input type="text" class="form-control" name="name" id="nameInput">
                    </div>
                    <div class="form-group col-md-6">
                        <label for="emailInput">E-mail</label>
                        <input type="email" class="form-control" name="email" id="emailInput">
                    </div>
                </div>
                <div class="form-group">
                    <label for="taskInput">Задача</label>
                    <textarea class="form-control" name="task" id="taskInput"></textarea>
                </div>
                <input hidden="hidden" type="text" value="0" name="status">
                <input hidden="hidden" type="text" value="0" name="edit">
                <input hidden="hidden" type="text" value="<?php echo $_GET['Id']; ?>" name="idInput">
                <input hidden="hidden" type="text" value="insertTask" name="modInput">
                <button type="submit" class="btn btn-info sendButton">Отправить</button>

                <div id="resultForm" class="mt-3"></div>
            </form>
        </div>
    </>
</div>
<footer>

</footer>
</body>
</html>
