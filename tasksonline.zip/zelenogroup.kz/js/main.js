$(document).ready(function() {

    selectTasks('id DESC', '');
    paginationTasks();

    $("#selectSort").change(function() {
        $("#sortInput").val($(this).val());
        selectTasks($(this).val(), '');
        $('.pagination-link').each(function() {
            $(this).removeClass('active');
        });
        $('.first-page').addClass('active');
    });

    $("#pagination").on('click', '.pagination-link', function() {
        selectTasks($("#selectSort").val(), 'OFFSET '+$(this).attr('data-offset'));
        $('.pagination-link').each(function() {
            $(this).removeClass('active');
        });
        $(this).addClass('active');
    });

    $(".sendButton").click(
        function(){
            if ($('#nameInput').val()=='' || $('#emailInput').val()=='' || $('#taskInput').val()==''){
                $('#resultForm').html('<div class="alert alert-danger" role="alert">Ошибка. Заполните все поля формы.</div>');
            } else
            {
                var pattern = /^[a-z0-9_-]+@[a-z0-9-]+\.[a-z]{2,6}$/i;
                var mail = $('#emailInput').val();

                if(mail.search(pattern) == 0){
                    sendForm('resultForm', 'ajaxForm', 'includes/controller.php');
                    selectTasks($('#selectSort').val(), '');
                    paginationTasks();
                }else{
                    $('#resultForm').html('<div class="alert alert-danger" role="alert">Ошибка. Поле E-mail заполнено не правильно.</div>');
                }
                }

            return false;
        }
    );

    $(".loginButton").click(
        function(){
            if ($('#login').val()=='' && $('#pass').val()==''){
                $('#errorList').html('<div class="alert alert-danger" role="alert">Ошибка. Заполните все поля формы.</div>');
            } else {
                if ($('#login').val()==''){
                    $('#errorList').html('<div class="alert alert-danger" role="alert">Ошибка. Укажите логин администратора.</div>');
                } else if ($('#pass').val()==''){
                    $('#errorList').html('<div class="alert alert-danger" role="alert">Ошибка. Укажите пароль администратора.</div>');
                } else {
                    loginUser('errorList', 'ajaxLogin', 'includes/controller.php');
                }
            }

            return false;
        }
    );

    $("#ajaxLogin input").click(function() {
        $('#errorList').html('');
    });

});

function sendForm(resultForm, ajaxForm, url) {
    $.ajax({
        url:     url,
        type:     "POST",
        dataType: "html",
        data: $("#"+ajaxForm).serialize(),
        success: function(response) {
            result = $.parseJSON(response);
            $('#resultForm').html('<div class="alert alert-success" role="alert">' + result + '</div>');
            $('form input.formInput, form textarea').val('');
        },
        error: function(response) {
            $('#resultForm').html('<div class="alert alert-danger" role="alert">Ошибка. Данные не отправлены.</div>');
        }
    });
}

function selectTasks(sort, offset){
    $.ajax({
        url:     "includes/controller.php",
        type:     "POST",
        dataType: "html",
        data: "modInput=selectTask&sort="+sort+"&offset="+offset,
        success: function(html) {
            $('#tasks').html(html)
        },
        error: function(response) {
            $('#tasks').html('<div class="alert alert-danger" role="alert">Ошибка. Данные не были загружены. Обновить страницу.</div>');
        }
    });
}

function paginationTasks(){
    $.ajax({
        url:     "includes/controller.php",
        type:     "POST",
        dataType: "html",
        data: "modInput=paginationTask",
        success: function(html) {
            $('.paginationItems').html(html)
        }
    });
}

function loginUser(resultForm, ajaxForm, url){
    $.ajax({
        url:     "includes/controller.php",
        type:     "POST",
        dataType: "html",
        data: $("#"+ajaxForm).serialize(),
        success: function(html) {
            $('#errorList').html('<div class="alert alert-success" role="alert">Добро пожаловать.</div>');
            $('#staticBackdrop').modal('hide');
            $('.login').fadeOut();
            $('.logout').fadeIn();
            selectTasks($('#selectSort').val(), '');
            paginationTasks();
        },
        error: function(html) {
            $('#errorList').html('<div class="alert alert-danger" role="alert">Логин или пароль не правильный.</div>');
        }
    });
}
