-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: srv-pleskdb44.ps.kz:3306
-- Generation Time: Nov 08, 2020 at 03:29 PM
-- Server version: 10.2.34-MariaDB
-- PHP Version: 7.3.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smartst3_task_bd`
--

-- --------------------------------------------------------

--
-- Table structure for table `Tasks`
--

CREATE TABLE `Tasks` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `task` text NOT NULL,
  `status` int(11) NOT NULL,
  `edit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Tasks`
--

INSERT INTO `Tasks` (`id`, `name`, `email`, `task`, `status`, `edit`) VALUES
(2, 'Тимур', 'timur.iskandarov96@gmail.com', 'Подготовить html главной страницы со списком задач', 0, 0),
(4, 'Тимур', 'timur.iskandarov96@gmail.com', 'Разработать скрипт PHP вывода задач на главную страницу', 2, 0),
(5, 'Тимур', 'timur.iskandarov96@gmail.com', 'Написать html форму для добавления задач в базу данных', 1, 0),
(6, 'Тимур', 'timur.iskandarov96@gmail.com', 'Проверить функцию добавления задачи', 0, 0),
(7, 'Timur', 'timur-iskandarov96@gmail.com', 'Протестировать Ajax отправку формы', 0, 1),
(72, 'aaaaaa', 'aaaaaaaaa@aaaa.aa', 'aaaaaaaaaaaaaaaaaaaaaa', 0, 0),
(73, 'zzzzzz', 'zzzzz@zzzzz.zz', 'zzzzzzzzzzzzz', 0, 0),
(74, 'ssssss', 'sssss@ssss.ssss', 'ssssssssssssssssssssssss11', 2, 1),
(75, 'wwwwwwwwwwwwww', 'wwwww@wwww.www', 'wwwwwwwwwwwwwwww11111', 2, 1),
(76, 'Пчёл', 'cholpan1996@mail.ru', 'Достать мёд', 2, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Tasks`
--
ALTER TABLE `Tasks`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Tasks`
--
ALTER TABLE `Tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
